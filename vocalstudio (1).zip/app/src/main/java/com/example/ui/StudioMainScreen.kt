package com.example.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.ai.SeparationMode
import com.example.ui.components.WaveformView
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudioMainScreen(
    viewModel: VocalStudioViewModel,
    selectedTrack: SelectedTrackInfo?,
    selectedMode: SeparationMode,
    onStartSeparation: () -> Unit,
    onNavigateToHistory: () -> Unit,
    onNavigateToDiagnostic: () -> Unit
) {
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let { viewModel.onAudioFileSelected(it) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(PolishPrimary),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.GraphicEq,
                                contentDescription = null,
                                tint = PolishOnPrimary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "VocalStudio",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Medium,
                                letterSpacing = (-0.3).sp,
                                color = TextPrimary
                            )
                            Text(
                                text = "Offline AI Stem Separator",
                                fontSize = 11.sp,
                                color = PolishPrimary
                            )
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = onNavigateToDiagnostic,
                        modifier = Modifier.testTag("diagnostic_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Speed,
                            contentDescription = "Diagnostics",
                            tint = TextSecondary
                        )
                    }
                    IconButton(
                        onClick = onNavigateToHistory,
                        modifier = Modifier.testTag("history_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = "History",
                            tint = TextSecondary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = PolishBackground
                )
            )
        },
        containerColor = PolishBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            // Status Badge
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(PolishSurfaceVariant)
                    .border(BorderStroke(1.dp, BorderSubtle), RoundedCornerShape(50))
                    .padding(horizontal = 14.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(PolishSuccess)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "100% On-Device Local Inference • Zero Latency Cloudless",
                    fontSize = 11.sp,
                    color = TextSecondary,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // File Selection Hero Area
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(28.dp))
                    .clickable { filePickerLauncher.launch("audio/*") }
                    .testTag("file_picker_card"),
                color = PolishSurface,
                border = BorderStroke(1.dp, if (selectedTrack != null) PolishPrimary else BorderSubtle)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (selectedTrack == null) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(PolishSurfaceVariant)
                                .border(BorderStroke(1.dp, BorderSubtle), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AudioFile,
                                contentDescription = null,
                                tint = PolishPrimary,
                                modifier = Modifier.size(32.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = "Select Music File",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "Tap to choose MP3, WAV, or M4A from your device",
                            fontSize = 13.sp,
                            color = TextMuted
                        )

                        Spacer(modifier = Modifier.height(18.dp))

                        Button(
                            onClick = { filePickerLauncher.launch("audio/*") },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = PolishPrimary,
                                contentColor = PolishOnPrimary
                            ),
                            shape = RoundedCornerShape(50),
                            modifier = Modifier
                                .height(46.dp)
                                .testTag("browse_audio_button")
                        ) {
                            Icon(imageVector = Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Browse Audio", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        }
                    } else {
                        // Track Loaded State
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(PolishPrimary),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.MusicNote,
                                    contentDescription = null,
                                    tint = PolishOnPrimary,
                                    modifier = Modifier.size(26.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(14.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = selectedTrack.title,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = TextPrimary,
                                    maxLines = 1
                                )
                                Spacer(modifier = Modifier.height(3.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Surface(
                                        color = BorderSubtle,
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = selectedTrack.format,
                                            color = PolishPrimary,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "${formatSec(selectedTrack.durationSeconds)} • ${selectedTrack.sampleRate} Hz",
                                        fontSize = 12.sp,
                                        color = TextSecondary
                                    )
                                }
                            }

                            IconButton(
                                onClick = { filePickerLauncher.launch("audio/*") },
                                modifier = Modifier.testTag("change_track_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ChangeCircle,
                                    contentDescription = "Change Track",
                                    tint = PolishPrimary
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Waveform Preview
                        WaveformView(
                            amplitudes = selectedTrack.waveformPoints,
                            activeColor = PolishPrimary,
                            inactiveColor = PolishSurfaceCard,
                            height = 42.dp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Separation Mode Selector
            Text(
                text = "SEPARATION MODE",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.2.sp,
                color = TextSecondary
            )

            Spacer(modifier = Modifier.height(10.dp))

            // 2-Stem Card
            ModeCard(
                title = "Vocal Removal (2-Stem)",
                subtitle = "Extracts pure Vocals and Instrumental accompaniment",
                stems = listOf("Vocals", "Instrumental"),
                isSelected = selectedMode == SeparationMode.VOCAL_REMOVAL,
                onClick = { viewModel.setSeparationMode(SeparationMode.VOCAL_REMOVAL) },
                testTag = "mode_2stem_card"
            )

            Spacer(modifier = Modifier.height(10.dp))

            // 4-Stem Card
            ModeCard(
                title = "Full Stem Separation (4-Stem)",
                subtitle = "Splits into Vocals, Drums, Bass, and Other melodic tracks",
                stems = listOf("Vocals", "Drums", "Bass", "Other"),
                isSelected = selectedMode == SeparationMode.FULL_STEMS,
                onClick = { viewModel.setSeparationMode(SeparationMode.FULL_STEMS) },
                testTag = "mode_4stem_card"
            )

            Spacer(modifier = Modifier.height(26.dp))

            // Primary CTA Button (Pill shaped as in Professional Polish theme)
            Button(
                onClick = onStartSeparation,
                enabled = selectedTrack != null,
                colors = ButtonDefaults.buttonColors(
                    containerColor = PolishPrimary,
                    contentColor = PolishOnPrimary,
                    disabledContainerColor = PolishSurfaceVariant,
                    disabledContentColor = TextMuted
                ),
                shape = RoundedCornerShape(50),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("start_separation_button")
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = if (selectedTrack != null) "Separate Audio Stems" else "Select a Song to Begin",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "OFFLINE AI ENGINE V2.4 (HIGH PRECISION)",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = TextMuted,
                letterSpacing = 2.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
fun ModeCard(
    title: String,
    subtitle: String,
    stems: List<String>,
    isSelected: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .testTag(testTag),
        color = if (isSelected) PolishSurface else PolishSurfaceVariant,
        border = BorderStroke(
            1.5.dp,
            if (isSelected) PolishPrimary else BorderSubtle
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RadioButton(
                selected = isSelected,
                onClick = onClick,
                colors = RadioButtonDefaults.colors(
                    selectedColor = PolishPrimary,
                    unselectedColor = TextMuted
                )
            )

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = subtitle,
                    fontSize = 12.sp,
                    color = TextSecondary
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    stems.forEach { stem ->
                        Surface(
                            color = BorderSubtle,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = stem,
                                color = PolishPrimary,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun formatSec(sec: Double): String {
    val totalSec = sec.toInt()
    val min = totalSec / 60
    val s = totalSec % 60
    return "%d:%02d".format(min, s)
}

