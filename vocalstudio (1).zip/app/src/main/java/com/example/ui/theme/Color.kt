package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// "Professional Polish" Design Theme Palette
val PolishBackground = Color(0xFF1C1B1F)       // Deep slate dark background
val PolishSurface = Color(0xFF2B2930)          // Primary card container
val PolishSurfaceVariant = Color(0xFF211F26)   // Secondary list & inset container
val PolishSurfaceCard = Color(0xFF36343B)      // Inset card / floating bar container

val PolishPrimary = Color(0xFFD0BCFF)          // Radiant Lilac accent
val PolishPrimaryDark = Color(0xFF6750A4)      // Medium violet
val PolishOnPrimary = Color(0xFF381E72)        // Deep violet text/icons on primary
val PolishPrimaryContainer = Color(0xFF4F378B) // Deep lilac container
val PolishOnPrimaryContainer = Color(0xFFEADDFF)

val PolishSecondary = Color(0xFFCCC2DC)
val PolishOnSecondary = Color(0xFF332D41)
val PolishSecondaryContainer = Color(0xFF4A4458)
val PolishOnSecondaryContainer = Color(0xFFE8DEF8)

val PolishTertiary = Color(0xFFEFB8C8)
val PolishOnTertiary = Color(0xFF492532)

val TextPrimary = Color(0xFFE6E1E5)            // Clean readable primary text
val TextSecondary = Color(0xFFCAC4D0)          // Secondary metadata
val TextMuted = Color(0xFF938F99)              // Muted labels & subtle info

val BorderSubtle = Color(0xFF49454F)           // Outline border
val BorderMedium = Color(0xFF938F99)           // Accent outline border

val ErrorRed = Color(0xFFF2B8B5)               // Soft coral error/cancel
val OnError = Color(0xFF601410)
val ErrorContainer = Color(0xFF8C1D18)

val PolishSuccess = Color(0xFFA8E6CF)          // Soft mint success

// Theme Mappings
val StudioBackground = PolishBackground
val StudioSurface = PolishSurface
val StudioSurfaceVariant = PolishSurfaceVariant
val StudioSurfaceCard = PolishSurfaceCard

val NeonCyan = PolishPrimary
val NeonPurple = PolishPrimaryContainer
val NeonPink = PolishTertiary
val NeonAmber = PolishSecondary
val NeonGreen = PolishSuccess

