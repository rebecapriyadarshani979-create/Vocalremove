package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val VocalStudioColorScheme = darkColorScheme(
    primary = PolishPrimary,
    onPrimary = PolishOnPrimary,
    primaryContainer = PolishPrimaryContainer,
    onPrimaryContainer = PolishOnPrimaryContainer,
    secondary = PolishSecondary,
    onSecondary = PolishOnSecondary,
    secondaryContainer = PolishSecondaryContainer,
    onSecondaryContainer = PolishOnSecondaryContainer,
    tertiary = PolishTertiary,
    onTertiary = PolishOnTertiary,
    background = PolishBackground,
    onBackground = TextPrimary,
    surface = PolishSurface,
    onSurface = TextPrimary,
    surfaceVariant = PolishSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = BorderSubtle,
    outlineVariant = BorderMedium,
    error = ErrorRed,
    onError = OnError,
    errorContainer = ErrorContainer
)

@Composable
fun VocalStudioTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = VocalStudioColorScheme,
        typography = Typography,
        content = content
    )
}
