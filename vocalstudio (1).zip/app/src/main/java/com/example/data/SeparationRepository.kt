package com.example.data

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.MediaStore
import android.util.Log
import com.example.audio.ai.StemType
import com.example.audio.core.AndroidAudioEncoder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.*

class SeparationRepository(private val context: Context) {

    private val db = AppDatabase.getInstance(context)
    private val dao = db.separationDao()

    val allRecords: Flow<List<SeparationRecord>> = dao.getAllRecords()

    /**
     * Gets the app-private working directory for processed stems.
     */
    fun getStemsDirectory(): File {
        val dir = File(context.filesDir, "stems")
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return dir
    }

    /**
     * Returns available internal storage in megabytes (MB).
     */
    fun getAvailableStorageMb(): Long {
        val stat = StatFs(context.filesDir.absolutePath)
        return (stat.availableBlocksLong * stat.blockSizeLong) / (1024 * 1024)
    }

    /**
     * Saves a completed separation session to database.
     */
    suspend fun saveSession(
        title: String,
        sourceUri: String?,
        durationSec: Double,
        mode: String,
        stemsMap: Map<StemType, File>,
        format: String = "MP3",
        sampleRate: Int = 44100
    ): Long = withContext(Dispatchers.IO) {
        val json = JSONObject()
        stemsMap.forEach { (stem, file) ->
            json.put(stem.id, file.absolutePath)
        }

        val record = SeparationRecord(
            trackTitle = title,
            sourceUriString = sourceUri,
            durationSeconds = durationSec,
            separationMode = mode,
            stemsJson = json.toString(),
            outputFormat = format,
            sampleRate = sampleRate
        )

        return@withContext dao.insertRecord(record)
    }

    /**
     * Parses stored stems JSON into Map<StemType, File>.
     */
    fun parseStemsJson(jsonStr: String): Map<StemType, File> {
        val map = mutableMapOf<StemType, File>()
        try {
            val json = JSONObject(jsonStr)
            for (stem in StemType.values()) {
                if (json.has(stem.id)) {
                    val path = json.getString(stem.id)
                    val file = File(path)
                    if (file.exists()) {
                        map[stem] = file
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("SeparationRepo", "Error parsing stems JSON: ${e.message}")
        }
        return map
    }

    /**
     * Deletes a separation record and its associated audio files.
     */
    suspend fun deleteSession(record: SeparationRecord) = withContext(Dispatchers.IO) {
        val stems = parseStemsJson(record.stemsJson)
        stems.values.forEach { file ->
            if (file.exists()) {
                file.delete()
            }
        }
        dao.deleteRecord(record)
    }

    /**
     * Exports a single audio file as a standalone MP3 file to Downloads/VocalStudio using Scoped Storage.
     * Returns the Uri of the saved file.
     */
    suspend fun exportStemAsMp3ToDownloads(wavFile: File, displayFileName: String): Uri? = withContext(Dispatchers.IO) {
        if (!wavFile.exists()) return@withContext null

        val mp3FileName = if (displayFileName.endsWith(".mp3", ignoreCase = true)) {
            displayFileName
        } else {
            "${displayFileName.substringBeforeLast(".")}.mp3"
        }

        val tempMp3File = File(context.cacheDir, "export_${System.currentTimeMillis()}_$mp3FileName")
        val isEncoded = AndroidAudioEncoder.encodeWavToMp3(wavFile, tempMp3File)
        val fileToSave = if (isEncoded && tempMp3File.exists()) tempMp3File else wavFile

        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, mp3FileName)
            put(MediaStore.MediaColumns.MIME_TYPE, "audio/mpeg")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/VocalStudio")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
        }

        val resolver = context.contentResolver
        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Downloads.EXTERNAL_CONTENT_URI
        } else {
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }

        val itemUri = resolver.insert(collection, values) ?: return@withContext null

        try {
            resolver.openOutputStream(itemUri)?.use { out ->
                FileInputStream(fileToSave).use { input ->
                    input.copyTo(out)
                }
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                values.clear()
                values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                resolver.update(itemUri, values, null, null)
            }

            if (tempMp3File.exists()) tempMp3File.delete()
            return@withContext itemUri
        } catch (e: Exception) {
            Log.e("SeparationRepo", "Export error: ${e.message}", e)
            if (tempMp3File.exists()) tempMp3File.delete()
            return@withContext null
        }
    }

    /**
     * Exports ALL stems as individual separate MP3 files (NO ZIP) to Downloads/VocalStudio.
     * Returns the count of successfully saved files.
     */
    suspend fun exportAllStemsAsIndividualMp3s(
        trackTitle: String,
        stemsMap: Map<StemType, File>
    ): Int = withContext(Dispatchers.IO) {
        val safeTitle = trackTitle.replace("[^a-zA-Z0-9_-]".toRegex(), "_")
        var savedCount = 0

        for ((stem, file) in stemsMap) {
            if (file.exists()) {
                val fileName = "${safeTitle}_${stem.label}.mp3"
                val uri = exportStemAsMp3ToDownloads(file, fileName)
                if (uri != null) {
                    savedCount++
                }
            }
        }

        return@withContext savedCount
    }
}
