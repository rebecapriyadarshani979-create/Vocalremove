package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Persisted record of a stem separation session.
 */
@Entity(tableName = "separation_records")
data class SeparationRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val trackTitle: String,
    val sourceUriString: String?,
    val durationSeconds: Double,
    val createdAt: Long = System.currentTimeMillis(),
    val separationMode: String, // VOCAL_REMOVAL or FULL_STEMS
    val stemsJson: String, // JSON map of StemType.id -> local file path
    val outputFormat: String = "WAV",
    val sampleRate: Int = 44100
)
