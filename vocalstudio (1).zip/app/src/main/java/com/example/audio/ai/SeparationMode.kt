package com.example.audio.ai

/**
 * Supported stem separation modes.
 */
enum class SeparationMode(val displayName: String, val stems: List<StemType>) {
    VOCAL_REMOVAL(
        displayName = "2-Stem (Vocals & Instrumental)",
        stems = listOf(StemType.VOCALS, StemType.INSTRUMENTAL)
    ),
    FULL_STEMS(
        displayName = "4-Stem (Vocals, Drums, Bass, Other)",
        stems = listOf(StemType.VOCALS, StemType.DRUMS, StemType.BASS, StemType.OTHER)
    )
}

enum class StemType(val id: String, val label: String, val colorHex: Long) {
    VOCALS("vocals", "Vocals", 0xFFFF4081),
    INSTRUMENTAL("instrumental", "Instrumental", 0xFF00E5FF),
    DRUMS("drums", "Drums", 0xFFFF9100),
    BASS("bass", "Bass", 0xFF7C4DFF),
    OTHER("other", "Other", 0xFF00E676)
}
