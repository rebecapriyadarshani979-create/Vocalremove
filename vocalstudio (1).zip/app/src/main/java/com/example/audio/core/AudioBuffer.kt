package com.example.audio.core

import kotlin.math.*

/**
 * High-precision stereo audio buffer holding floating-point PCM audio in range [-1.0f, 1.0f].
 */
data class AudioBuffer(
    val left: FloatArray,
    val right: FloatArray,
    val sampleRate: Int = 44100
) {
    val sampleCount: Int = min(left.size, right.size)

    init {
        require(sampleRate > 0) { "Sample rate must be positive, got $sampleRate" }
    }

    val durationSeconds: Double
        get() = sampleCount.toDouble() / sampleRate

    /**
     * Computes the Root Mean Square (RMS) level in linear scale [0.0, 1.0].
     */
    fun computeRms(): Float {
        if (sampleCount == 0) return 0f
        var sumSquares = 0.0
        for (i in 0 until sampleCount) {
            val l = left[i]
            val r = right[i]
            sumSquares += (l * l + r * r) * 0.5
        }
        return sqrt(sumSquares / sampleCount).toFloat()
    }

    /**
     * Computes peak amplitude [0.0, 1.0].
     */
    fun computePeak(): Float {
        var peak = 0f
        for (i in 0 until sampleCount) {
            val l = abs(left[i])
            val r = abs(right[i])
            if (l > peak) peak = l
            if (r > peak) peak = r
        }
        return peak
    }

    /**
     * Checks if buffer contains any NaN or Infinite samples.
     */
    fun hasInvalidSamples(): Boolean {
        for (i in 0 until sampleCount) {
            val l = left[i]
            val r = right[i]
            if (l.isNaN() || l.isInfinite() || r.isNaN() || r.isInfinite()) {
                return true
            }
        }
        return false
    }

    /**
     * Applies a soft-knee audio limiter to prevent digital clipping while preserving dynamics.
     */
    fun applySoftLimiter(threshold: Float = 0.95f): AudioBuffer {
        val outL = FloatArray(sampleCount)
        val outR = FloatArray(sampleCount)
        for (i in 0 until sampleCount) {
            outL[i] = softClip(left[i], threshold)
            outR[i] = softClip(right[i], threshold)
        }
        return AudioBuffer(outL, outR, sampleRate)
    }

    private fun softClip(sample: Float, threshold: Float): Float {
        if (sample > threshold) {
            val diff = sample - threshold
            return threshold + (1f - threshold) * tanh(diff / (1f - threshold))
        } else if (sample < -threshold) {
            val diff = -sample - threshold
            return -(threshold + (1f - threshold) * tanh(diff / (1f - threshold)))
        }
        return sample
    }

    /**
     * Converts to 16-bit signed PCM Little-Endian bytes.
     */
    fun toPcm16LittleEndian(): ByteArray {
        val bytes = ByteArray(sampleCount * 4) // 2 channels * 2 bytes/sample
        var byteIdx = 0
        for (i in 0 until sampleCount) {
            val lClamped = max(-1.0f, min(1.0f, left[i]))
            val rClamped = max(-1.0f, min(1.0f, right[i]))

            val lShort = (lClamped * 32767.0f).roundToInt().coerceIn(-32768, 32767).toShort()
            val rShort = (rClamped * 32767.0f).roundToInt().coerceIn(-32768, 32767).toShort()

            bytes[byteIdx++] = (lShort.toInt() and 0xFF).toByte()
            bytes[byteIdx++] = ((lShort.toInt() shr 8) and 0xFF).toByte()
            bytes[byteIdx++] = (rShort.toInt() and 0xFF).toByte()
            bytes[byteIdx++] = ((rShort.toInt() shr 8) and 0xFF).toByte()
        }
        return bytes
    }

    companion object {
        fun silence(sampleCount: Int, sampleRate: Int = 44100): AudioBuffer {
            return AudioBuffer(FloatArray(sampleCount), FloatArray(sampleCount), sampleRate)
        }
    }
}
