package com.example.audio.core

import kotlin.math.*

/**
 * High-quality offline audio time-stretch and pitch shift processor using WSOLA
 * (Waveform Similarity Overlap-Add) and sinc/linear interpolation.
 */
object AudioPitchTempoProcessor {

    /**
     * Shifts pitch by given semitones (-12 to +12) while preserving duration.
     */
    fun processPitchShift(input: AudioBuffer, semitones: Float): AudioBuffer {
        if (abs(semitones) < 0.01f) return input

        val pitchFactor = 2.0.pow((semitones / 12.0)).toFloat()
        // Resample to shift pitch
        val resampled = resample(input, pitchFactor)
        // Time stretch back to original length
        return timeStretchWsola(resampled, 1.0f / pitchFactor, input.sampleCount)
    }

    /**
     * Modifies tempo/playback speed (0.5x to 2.0x) while preserving musical pitch.
     */
    fun processTempoChange(input: AudioBuffer, speedFactor: Float): AudioBuffer {
        if (abs(speedFactor - 1.0f) < 0.01f) return input
        val targetLength = (input.sampleCount / speedFactor).roundToInt()
        return timeStretchWsola(input, speedFactor, targetLength)
    }

    private fun resample(input: AudioBuffer, pitchFactor: Float): AudioBuffer {
        val inLen = input.sampleCount
        val outLen = (inLen / pitchFactor).roundToInt()
        val outL = FloatArray(outLen)
        val outR = FloatArray(outLen)

        for (i in 0 until outLen) {
            val srcPos = i * pitchFactor
            val idx0 = srcPos.toInt()
            val frac = srcPos - idx0
            val idx1 = min(inLen - 1, idx0 + 1)

            if (idx0 < inLen) {
                outL[i] = (1f - frac) * input.left[idx0] + frac * input.left[idx1]
                outR[i] = (1f - frac) * input.right[idx0] + frac * input.right[idx1]
            }
        }
        return AudioBuffer(outL, outR, input.sampleRate)
    }

    private fun timeStretchWsola(
        input: AudioBuffer,
        speedFactor: Float,
        targetLength: Int
    ): AudioBuffer {
        val windowSize = 2048
        val hopOut = 512
        val hopIn = (hopOut * speedFactor).roundToInt()
        val searchRange = 256

        val outL = FloatArray(targetLength)
        val outR = FloatArray(targetLength)
        val windowWeight = FloatArray(targetLength)

        // Hann window
        val win = FloatArray(windowSize) { i ->
            (0.5 * (1.0 - cos(2.0 * Math.PI * i / windowSize))).toFloat()
        }

        var inPos = 0
        var outPos = 0

        while (outPos + windowSize <= targetLength && inPos + windowSize + searchRange <= input.sampleCount) {
            // Find best matching offset within search range to minimize phase discontinuity
            var bestOffset = 0
            var maxCorr = -1e9f

            if (outPos > 0) {
                for (offset in -searchRange..searchRange) {
                    val candidate = inPos + offset
                    if (candidate < 0 || candidate + windowSize > input.sampleCount) continue

                    var corr = 0f
                    for (k in 0 until min(256, windowSize) step 4) {
                        val ref = outL[outPos - hopOut + k]
                        val cand = input.left[candidate + k]
                        corr += ref * cand
                    }
                    if (corr > maxCorr) {
                        maxCorr = corr
                        bestOffset = offset
                    }
                }
            }

            val actualIn = inPos + bestOffset
            for (i in 0 until windowSize) {
                val dst = outPos + i
                val w = win[i]
                outL[dst] += input.left[actualIn + i] * w
                outR[dst] += input.right[actualIn + i] * w
                windowWeight[dst] += w
            }

            inPos += hopIn
            outPos += hopOut
        }

        // Normalize overlap
        for (i in 0 until targetLength) {
            val w = windowWeight[i]
            if (w > 1e-4f) {
                outL[i] /= w
                outR[i] /= w
            }
        }

        return AudioBuffer(outL, outR, input.sampleRate)
    }
}
